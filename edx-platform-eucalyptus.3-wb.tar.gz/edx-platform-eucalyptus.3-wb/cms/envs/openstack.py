"""
Settings for OpenStack deployments.
"""

from .aws import *  # pylint: disable=wildcard-import, unused-wildcard-import

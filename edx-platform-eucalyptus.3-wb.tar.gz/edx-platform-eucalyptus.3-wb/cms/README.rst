CMS (Content Management System)
-------------------------------

This directory contains code relating to the course management portal for edX, also known as Studio.
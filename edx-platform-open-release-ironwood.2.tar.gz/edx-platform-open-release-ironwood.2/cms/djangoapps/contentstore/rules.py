"""
Authorization rules related to content management.
"""

from __future__ import absolute_import, unicode_literals

import user_tasks.rules

user_tasks.rules.add_rules()

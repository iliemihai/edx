define(['backbone'], function(Backbone) {
    var Checklist = Backbone.Model.extend({
    });
    return Checklist;
});

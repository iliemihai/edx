// We can't convert this to an es6 module until all factories that use it have been converted out
// of RequireJS
define(['js/base', 'cms/js/main', 'js/src/logger', 'datepair', 'accessibility',
    'ieshim', 'tooltip_manager', 'lang_edx', 'js/models/course'],
    function() {
        'use strict';
    }
);

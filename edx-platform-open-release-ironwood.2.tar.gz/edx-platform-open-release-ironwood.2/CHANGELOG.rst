We don't maintain a detailed changelog.  For details of changes, please see
either the `edX Release Notes`_ or the `GitHub commit history`_.

.. _edX Release Notes: https://edx.readthedocs.org/projects/edx-release-notes/en/latest/
.. _GitHub commit history: https://github.com/edx/edx-platform/commits/master
